import React from "react";
import styled from "styled-components";

const FooterBlock = styled.footer`
  
`;

const Footer = () => {
    return (
        <FooterBlock>

        </FooterBlock>
    );
}

export default Footer;