interface Routes {
    [index: string]: string
}

const Routes:Routes = {
    "/": "Главная",
    "/main": "Главная",
    "/brushing": "Чистка зубов",
    "/achievements": "Достижения"
}

export default Routes;